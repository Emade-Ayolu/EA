from flask import Flask, render_template, request, redirect, url_for, flash, session
import sqlite3
import os
from modules.aes_module import AESModule
from modules.rsa_module import RSAModule
from modules.steganography import Steganography

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "secure_video_streaming_project")
UPLOAD_FOLDER = os.path.join("static", "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# ---------------------------
# DATABASE CONNECTION
# ---------------------------
def get_db_connection():
    conn = sqlite3.connect("database.db")
    conn.row_factory = sqlite3.Row
    return conn


# ---------------------------
# LOGIN PAGE
# ---------------------------
@app.route("/")
def login():
    return render_template("login.html")


# ---------------------------
# LOGIN PROCESS
# ---------------------------
@app.route("/login", methods=["POST"])
def login_user():

    username = request.form["username"]
    password = request.form["password"]

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(
        "SELECT * FROM users WHERE username=? AND password=?",
        (username, password)
    )

    user = cursor.fetchone()

    conn.close()

    if user:

        session["username"] = username
        session["role"] = user["role"]

        # Send admin to admin dashboard
        if user["role"] == "admin":
            return redirect(url_for("admin_dashboard"))

        # Send normal users to normal dashboard
        return redirect(url_for("dashboard"))

    else:
        flash("Invalid Username or Password")
        return redirect(url_for("login"))


# ---------------------------
# REGISTER PAGE
# ---------------------------
@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        fullname = request.form["fullname"]
        email = request.form["email"]
        username = request.form["username"]
        password = request.form["password"]

        try:

            conn = get_db_connection()
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO users(fullname,email,username,password)
                VALUES(?,?,?,?)
            """, (fullname, email, username, password))

            conn.commit()
            conn.close()

            flash("Registration Successful!")
            return redirect(url_for("login"))

        except sqlite3.IntegrityError:

            flash("Username already exists!")
            return redirect(url_for("register"))

    return render_template("register.html")


# ---------------------------
# DASHBOARD
# ---------------------------
@app.route("/dashboard")
def dashboard():

    if "username" not in session:
        return redirect(url_for("login"))

    return render_template(
        "dashboard.html",
        username=session["username"]
    )
@app.route("/upload", methods=["POST"])
def upload():

    if "username" not in session:
        return redirect(url_for("login"))

    if "video" not in request.files:
        flash("No file selected.")
        return redirect(url_for("dashboard"))

    file = request.files["video"]

    if file.filename == "":
        flash("Please choose a video.")
        return redirect(url_for("dashboard"))

    filename = file.filename
    filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)

    file.save(filepath)

    flash("Video uploaded successfully!")

    return redirect(url_for("dashboard"))

# ---------------------------
# ENCRYPT VIDEO
# ---------------------------
@app.route("/encrypt")
def encrypt():

    if "username" not in session:
        return redirect(url_for("login"))

    upload_folder = app.config["UPLOAD_FOLDER"]
    encrypted_folder = os.path.join("static", "encrypted")

    os.makedirs(encrypted_folder, exist_ok=True)

    files = os.listdir(upload_folder)

    if not files:
        flash("No uploaded video found.")
        return redirect(url_for("dashboard"))

    latest_file = max(
        [os.path.join(upload_folder, f) for f in files],
        key=os.path.getctime
    )

    filename = os.path.basename(latest_file)

    output_file = os.path.join(
        encrypted_folder,
        "encrypted_" + filename
    )

    aes = AESModule()
    aes_key = aes.encrypt_file(latest_file, output_file)

    rsa = RSAModule()

    # Generate RSA keys only once
    if not os.path.exists("keys/public.pem"):
        rsa.generate_keys()

    rsa.encrypt_key(aes_key)

    flash("Video encrypted and AES key secured with RSA!")

    return redirect(url_for("dashboard"))

# ---------------------------
# HIDE AES KEY IN IMAGE
# ---------------------------
@app.route("/hide_key")
def hide_key():

    if "username" not in session:
        return redirect(url_for("login"))

    image_path = os.path.join("static", "images", "carrier.png")
    secret_file = os.path.join("keys", "encrypted_aes.key")
    output_image = os.path.join("static", "images", "stego_carrier.png")

    if not os.path.exists(secret_file):
        flash("Please encrypt a video first.")
        return redirect(url_for("dashboard"))

    steg = Steganography()

    try:
        steg.hide_file(image_path, secret_file, output_image)

        flash("AES key hidden successfully inside the image!")

    except Exception as e:
        flash(str(e))

    return redirect(url_for("dashboard"))
    
# ---------------------------
# DECRYPT VIDEO
# ---------------------------
@app.route("/decrypt")
def decrypt():

    if "username" not in session:
        return redirect(url_for("login"))

    try:

        steg = Steganography()

        steg.extract_file(
            os.path.join("static", "images", "stego_carrier.png"),
            os.path.join("keys", "extracted_aes.key")
        )

        rsa = RSAModule()
        aes_key = rsa.decrypt_key()

        encrypted_folder = os.path.join("static", "encrypted")
        decrypted_folder = os.path.join("static", "decrypted")

        os.makedirs(decrypted_folder, exist_ok=True)

        files = os.listdir(encrypted_folder)

        if not files:
            flash("No encrypted video found.")
            return redirect(url_for("dashboard"))

        latest_file = max(
            [os.path.join(encrypted_folder, f) for f in files],
            key=os.path.getctime
        )

        filename = os.path.basename(latest_file)

        output_file = os.path.join(
            decrypted_folder,
            "decrypted_" + filename.replace("encrypted_", "")
        )

        aes = AESModule()

        aes.decrypt_file(
            latest_file,
            output_file,
            aes_key
        )

        flash("Video decrypted successfully!")

    except Exception as e:
        flash(str(e))

    return redirect(url_for("dashboard"))

# ---------------------------
# PLAY DECRYPTED VIDEO
# ---------------------------
@app.route("/player")
def player():

    if "username" not in session:
        return redirect(url_for("login"))

    decrypted_folder = os.path.join("static", "decrypted")

    if not os.path.exists(decrypted_folder):
        flash("No decrypted video found.")
        return redirect(url_for("dashboard"))

    files = os.listdir(decrypted_folder)

    if not files:
        flash("No decrypted video found.")
        return redirect(url_for("dashboard"))

    latest_file = max(
        [os.path.join(decrypted_folder, f) for f in files],
        key=os.path.getctime
    )

    filename = os.path.basename(latest_file)

    return render_template(
        "player.html",
        video=filename
    )

# ---------------------------
# ADMIN DASHBOARD
# ---------------------------
@app.route("/admin")
def admin_dashboard():

    if "username" not in session:
        return redirect(url_for("login"))

    if session.get("role") != "admin":
        flash("Access denied. Admins only.")
        return redirect(url_for("dashboard"))

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT id, fullname, email, username, role FROM users")
    users = cursor.fetchall()

    conn.close()

    return render_template(
        "admin_dashboard.html",
        username=session["username"],
        users=users
    )
    
# ---------------------------
# LOGOUT
# ---------------------------
@app.route("/logout")
def logout():

    session.clear()

    flash("You have been logged out.")

    return redirect(url_for("login"))


# ---------------------------
# RUN APPLICATION
# ---------------------------
if __name__ == "__main__":
    app.run()
