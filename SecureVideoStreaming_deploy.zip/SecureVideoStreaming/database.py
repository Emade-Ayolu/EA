import sqlite3

connection = sqlite3.connect("database.db")
cursor = connection.cursor()

# Create users table if it does not already exist
cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fullname TEXT NOT NULL,
    email TEXT NOT NULL,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user'
)
""")

# Add role column if the existing database was created without it
try:
    cursor.execute("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'")
except sqlite3.OperationalError:
    # Column already exists
    pass

# Create default admin account
cursor.execute("""
INSERT OR IGNORE INTO users
(fullname, email, username, password, role)
VALUES (?, ?, ?, ?, ?)
""", (
    "System Administrator",
    "admin@example.com",
    "admin",
    "admin123",
    "admin"
))

connection.commit()
connection.close()

print("Database and users table created successfully.")
print("Admin account: username = admin, password = admin123")