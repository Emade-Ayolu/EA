from PIL import Image


class Steganography:

    def hide_file(self, image_path, secret_file, output_image):

        image = Image.open(image_path)
        image = image.convert("RGB")

        pixels = list(image.getdata())

        with open(secret_file, "rb") as f:
            secret = f.read()

        # Add an end marker
        secret += b"###END###"

        bits = []

        for byte in secret:
            bits.extend(format(byte, "08b"))

        if len(bits) > len(pixels) * 3:
            raise ValueError("Image is too small to hide the data.")

        new_pixels = []

        bit_index = 0

        for pixel in pixels:

            r, g, b = pixel
            rgb = [r, g, b]

            for i in range(3):

                if bit_index < len(bits):
                    rgb[i] = (rgb[i] & ~1) | int(bits[bit_index])
                    bit_index += 1

            new_pixels.append(tuple(rgb))

        image.putdata(new_pixels)
        image.save(output_image)

        return output_image


    def extract_file(self, image_path, output_file):

        image = Image.open(image_path)
        image = image.convert("RGB")

        pixels = list(image.getdata())

        bits = []

        for pixel in pixels:
            for value in pixel:
                bits.append(str(value & 1))

        data = bytearray()

        for i in range(0, len(bits), 8):

            byte = bits[i:i+8]

            if len(byte) < 8:
                break

            data.append(int("".join(byte), 2))

            if data.endswith(b"###END###"):
                data = data[:-9]
                break

        with open(output_file, "wb") as f:
            f.write(data)