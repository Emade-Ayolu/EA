from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad
import os


class AESModule:

    def encrypt_file(self, input_file, output_file):

        # Generate a 256-bit AES key
        key = get_random_bytes(32)

        # Save the AES key
        os.makedirs("keys", exist_ok=True)

        with open("keys/aes.key", "wb") as key_file:
            key_file.write(key)

        iv = get_random_bytes(16)

        cipher = AES.new(key, AES.MODE_CBC, iv)

        with open(input_file, "rb") as f:
            data = f.read()

        encrypted = cipher.encrypt(pad(data, AES.block_size))

        with open(output_file, "wb") as f:
            f.write(iv)
            f.write(encrypted)

        return key

    def decrypt_file(self, input_file, output_file, key):

        with open(input_file, "rb") as f:
            iv = f.read(16)
            encrypted = f.read()

        cipher = AES.new(key, AES.MODE_CBC, iv)

        decrypted = unpad(cipher.decrypt(encrypted), AES.block_size)

        with open(output_file, "wb") as f:
            f.write(decrypted)