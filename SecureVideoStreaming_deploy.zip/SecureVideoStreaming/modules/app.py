from flask import Flask, render_template, redirect, url_for
import os

app = Flask(__name__)

# Secret key
app.secret_key = "secure_video_streaming_project"

# Configure folders
UPLOAD_FOLDER = "static/uploads"
ENCRYPTED_FOLDER = "static/encrypted"
DECRYPTED_FOLDER = "static/decrypted"

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["ENCRYPTED_FOLDER"] = ENCRYPTED_FOLDER
app.config["DECRYPTED_FOLDER"] = DECRYPTED_FOLDER

# Create folders if they do not exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(ENCRYPTED_FOLDER, exist_ok=True)
os.makedirs(DECRYPTED_FOLDER, exist_ok=True)

# Home page
@app.route("/")
def home():
    return redirect(url_for("login"))

# Login page
@app.route("/login")
def login():
    return render_template("login.html")

# Register page
@app.route("/register")
def register():
    return render_template("register.html")

# Dashboard
@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

# Upload page
@app.route("/upload")
def upload():
    return render_template("upload.html")

# Video player
@app.route("/player")
def player():
    return render_template("player.html")

# Run the application
if __name__ == "__main__":
    app.run(debug=True)